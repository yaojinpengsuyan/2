#!/bin/bash
cd /home/login-register/login-register
python manage.py runserver 0.0.0.0:8000